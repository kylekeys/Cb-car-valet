# CB Car Valeting — Booking App

## Deploy this for free (recommended: Vercel)

1. Go to https://vercel.com and sign up (free) with GitHub, Google, or email.
2. Create a free GitHub account if you don't have one: https://github.com/signup
3. Create a new (empty) GitHub repository, e.g. "cb-car-valeting".
4. Upload all the files in this folder to that repository (GitHub's website lets you drag and drop files in — no command line needed: open the repo, click "Add file" > "Upload files").
5. Back in Vercel, click "Add New Project", select your GitHub repo, and click Deploy.
   Vercel auto-detects this as a Vite project — no settings need changing.
6. After a minute or two you'll get a live link like https://cb-car-valeting.vercel.app — that's the one you can send to anyone.

## Alternative: Netlify (also free, drag-and-drop, no GitHub needed)

1. On your own computer, install Node.js if you don't have it: https://nodejs.org
2. Open a terminal in this folder and run:
   npm install
   npm run build
   This creates a "dist" folder.
3. Go to https://app.netlify.com/drop and drag the "dist" folder onto the page.
4. Netlify gives you a live link instantly.

## Notes

- This is currently a working prototype: bookings and quote requests are stored only in the browser tab's memory, and reset on refresh. Real persistence (a database), real calendar sync, and real text/email reminders are the next layer to build once you're happy with the design and flow.
- Custom domain: once deployed, both Vercel and Netlify let you connect a real domain name (e.g. cbcarvaleting.co.uk) for free if you own one, or you can buy one through them.
